import * as yup from "yup";
import { useBoardContext } from "../context/AddNewBoardContext";

export const useTaskSchema = () => {
  const { boards, activeTab } = useBoardContext();
  const options = boards[activeTab].columns.map((column) => column.name);

  return yup.object().shape({
    title: yup.string().required("Title is required"),
    description: yup.string().required("Description is required"),
    subtasks: yup
      .array()
      .of(
        yup.object().shape({
          id: yup.number().required(),
          title: yup.string().required("Subtask title is required"),
        })
      )
      .min(1, "At least one subtask is required"),
    status: yup.string().required("Select a status").oneOf(options),
  });
};

export const boardSchema = yup.object().shape({
  name: yup
    .string()
    .required("Name is required")
    .test("unique-board-name", "Board name must be unique", function (value) {
      const { boards } = useBoardContext();
      const boardNames = boards.map((board) => board.name);
      return !boardNames.includes(value);
    }),
  columns: yup
    .array()
    .of(
      yup
        .string()
        .required("Required")
        .test(
          "unique-column-name",
          "Column names must be unique",
          function (value, context) {
            const columnNames = context.parent;
            return (
              columnNames.filter((name: string) => name === value).length === 1
            );
          }
        )
    )
    .min(1, "At least one column is required"),
});

export const newColumnSchema = yup.object().shape({
  columns: yup.array().of(
    yup.object({
      name: yup
        .string()
        .required("Required")
        .test(
          "unique-column-name",
          "Column names must be unique",
          function (value, context) {
            const columnNames = context.parent.map(
              (column: any) => column.name
            );
            return (
              columnNames.filter((name: string) => name === value).length === 1
            );
          }
        ),
    })
  ),
});
